package isil.eva.pe.jpa.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;
import isil.eva.pe.jpa.modelo.Carrito;

public interface CarritoRepositorio extends JpaRepository<Carrito, Integer> {
}
